# Release notes for proposed FTL methods v1.2.2

Prepared 2026-10-02 for owner review. Proposed archive category: publication/report. Creating or reading this package does not establish that Zenodo publication occurred; consult the public concept record for publication status. Initial publication requires owner review of this expanded package, version, category and metadata.

Read [RELEASE_DESCRIPTION.md](RELEASE_DESCRIPTION.md) for the claim boundary and [RELEASE_CITATION.cff](RELEASE_CITATION.cff) for the proposed edition citation. The [LICENSE](LICENSE) preserves CC BY 4.0 documentation/data and MIT source code. The historical [CITATION.cff](CITATION.cff), September snapshots and dated archive-verification documents remain byte-identical to the reviewed sources and do not supply the new edition's publication date or DOI.

This is a conditional mathematical/free-model methods report with synthetic and internal computational checks. It reports no empirical FTL detection, complete hidden-sector theory, new posterior bundle, externally reviewed result or novelty determination. Empirical v1.3.0 is not claimed. The preferred-time free model changes the propagation assumptions and is not an experimental validation of an observer-reciprocal FTL protocol.

The 40 entries in [SOURCE_MANIFEST.json](SOURCE_MANIFEST.json) match merged public main commit 7ad6a32a2f413b8f13c329ae685478b19ea42dd2. The scientific review was owner merged through https://github.com/maldonado-research/faster-than-light/pull/1 on 2026-10-02. This staging package adds only this cover, a description, a provisional citation, release metadata and the source manifest. It performs no new research or execution. [RELEASE_METADATA.json](RELEASE_METADATA.json) identifies the source and packaging boundaries.

The previous round04 candidate is preserved unchanged: SHA-256 6d6e0aa004b967861ad63b8db52a42f5e168643f065243fb4f3cec8a44d87369. Its three older candidate-review files are replaced in this staging ZIP by these five release files; none of the 40 original source files is changed. No new DOI-reservation or publish action was performed when this package was made.
